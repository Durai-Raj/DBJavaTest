package com.acme.mytrader.strategy;

import org.junit.Test;

public class TradingStrategyTest {
    @Test
    public void testNothing() {
    }
}
